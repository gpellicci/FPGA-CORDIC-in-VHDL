/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cordic;

/**
 *
 * @author Giacomo Pellicci
 */
public class NumberInfo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        approx a = new approx();
        a.showInfo();
        double num = 0.6072544793;
        System.out.print("Real Number is "+ num+'\n'+"Which binary is ");
        a.printBits(num);
        System.out.print('\n'+"Which integer is " + num/approx.getDelta() +'\n');
    }
    
}
