/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cordic;

import static java.lang.Math.sqrt;

/**
 *
 * @author Giacomo Pellicci
 */
public class CORDIC {

    double x;
    double y;
    double z;
    final double An;
    private static final int N_ITERATIONS = 8;
    int currentIteration;

    public CORDIC(double x, double y) {

        this.x = x;
        this.y = y;
        this.z = 0;
        this.An = 1.646;
        this.currentIteration = 0;
        System.out.println("***Starting x="+x+" y=" +y+"\n");

    }
    
    public double getAn(){
        return An;
    }

    public void iterate() {
        double tmpX = 0;
        double tmpY = 0;
        double tmpZ = 0;

        int d;
        if (y < 0) {
            d = -1;
        } else {
            d = 1;
        }

        double exp = 1 / Math.pow(2, currentIteration);
        //System.out.println("#"+currentIteration+"#\texp = "+exp+" d = "+ d +"\tx = " + x + "\ty = " + y + "\tz = " + z);

        tmpX = x + y * d * exp;
        tmpY = y - x * d * exp;
        tmpZ = z + d * Math.atan(exp);


        x = tmpX;
        y = tmpY;
        z = tmpZ;

        
        System.out.print("#"+currentIteration+"#\tx="+x + "\ty=" + y + "\tz=" + z + "\n");
           
        currentIteration++;
    }

    public void compute() {
        for (int i = 0; i < N_ITERATIONS; i++) {
            iterate();
        }
    }

    public void print() {
        System.out.println("\nResult after " + N_ITERATIONS + " iteration is:");
        System.out.println("Mod = " + (x/An) + "\tAngle = " + z + " rad");
    }


    public static void main(String[] args) {
        CORDIC k = new CORDIC(1,1);
        CORDIC c = new CORDIC(2, 3);
        
        c.compute();
        c.print();
                
    }

}
