/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cordic;

/**
 *
 * @author Giacomo Pellicci
 */
public class approx {

    private static final double delta = Math.pow(2, -8);

    public static double getDelta() {
        return delta;
    }

    public int computeIndex(double num) {
        int v = (int) Math.round(num / delta);
        return v;
    }

    public double computeApproxximation(double num) {
        int v = ((int) (num / delta));
        double f = v * delta;
        return f;
    }
    
    public void showInfo(){
        System.out.println("Resolution is "+delta);
        System.out.println("Range is from "+ (-Math.pow(2, 15))*delta +" to "+ (Math.pow(2, 15)-1)*delta);
    }
    
    public void printBits(double num){
        int v = computeIndex(num);
        System.out.print(Integer.toBinaryString(0x10000 | v).substring(1));       // 16bit
    }

}
