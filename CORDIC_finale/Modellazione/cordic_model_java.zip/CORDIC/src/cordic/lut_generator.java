/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cordic;

/**
 *
 * @author Giacomo Pellicci
 */
public class lut_generator {

    int N_ITERATIONS;
    int SCALING_FACTOR;
    double delta;
    double pow;
    approx a;

    public lut_generator(int N_ITERATIONS, int SCALING_FACTOR) {
        this.N_ITERATIONS = N_ITERATIONS;
        this.SCALING_FACTOR = SCALING_FACTOR;
        this.delta = Math.pow(2, -delta);
        this.pow = Math.pow(2, delta);
        this.a = new approx();
    }

    public void compute(boolean b) {
        System.out.println("-- Look up table cells\nconstant lut : lut_t := (");
        if (b) {
            for (int i = 0; i < N_ITERATIONS; i++) {
                double r = Math.atan(Math.pow(2, -i));
                System.out.print("#"+i+"\t");
                a.printBits(r);
                System.out.println("\t"+ r +'\t'+ r/Math.pow(2, -8) +"\t" + a.computeIndex(r) +"\t" + Math.round(r/Math.pow(2, -8)) );
            }
        } else {
            for (int i = 0; i < N_ITERATIONS; i++) {
                double r = Math.atan(Math.pow(2, -i));
                System.out.print("\t" + '"');
                a.printBits(r);
                
                if (i == N_ITERATIONS - 1) {
                    System.out.println('"' + "\n);");
                } else {
                    System.out.println('"' + ",");
                }
            }
        }
    }
    
    public void kappa(){
        System.out.println("Kappa:");
        a.printBits(0.6072544793);
    }

    public static void main(String[] args) {
        int N = 8;
        int S = 10;
        lut_generator lg = new lut_generator(N, S);
        lg.compute(false);
        lg.compute(true);
        lg.kappa();
    }
}
